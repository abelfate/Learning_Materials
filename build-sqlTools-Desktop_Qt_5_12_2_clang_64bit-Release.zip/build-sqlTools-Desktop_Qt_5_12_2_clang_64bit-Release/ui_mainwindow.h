/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QGridLayout *gridLayout_2;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QTableWidget *dataTableWidget;
    QVBoxLayout *layouEdit_4;
    QLineEdit *qqIdEdit;
    QLineEdit *phoneIdEdit;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *selectPushButton;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *clearPushButton;
    QSpacerItem *horizontalSpacer_12;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(600, 600);
        MainWindow->setMinimumSize(QSize(600, 600));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        dataTableWidget = new QTableWidget(groupBox);
        if (dataTableWidget->columnCount() < 5)
            dataTableWidget->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        dataTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        dataTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        dataTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        dataTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        dataTableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        dataTableWidget->setObjectName(QString::fromUtf8("dataTableWidget"));

        verticalLayout_2->addWidget(dataTableWidget);

        layouEdit_4 = new QVBoxLayout();
        layouEdit_4->setObjectName(QString::fromUtf8("layouEdit_4"));
        qqIdEdit = new QLineEdit(groupBox);
        qqIdEdit->setObjectName(QString::fromUtf8("qqIdEdit"));
        qqIdEdit->setMaxLength(15);
        qqIdEdit->setEchoMode(QLineEdit::Normal);
        qqIdEdit->setCursorPosition(0);
        qqIdEdit->setCursorMoveStyle(Qt::LogicalMoveStyle);

        layouEdit_4->addWidget(qqIdEdit);

        phoneIdEdit = new QLineEdit(groupBox);
        phoneIdEdit->setObjectName(QString::fromUtf8("phoneIdEdit"));
        phoneIdEdit->setMaxLength(21);

        layouEdit_4->addWidget(phoneIdEdit);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_10);

        selectPushButton = new QPushButton(groupBox);
        selectPushButton->setObjectName(QString::fromUtf8("selectPushButton"));
        selectPushButton->setMinimumSize(QSize(40, 40));
        selectPushButton->setIconSize(QSize(16, 16));

        horizontalLayout_4->addWidget(selectPushButton);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_11);

        clearPushButton = new QPushButton(groupBox);
        clearPushButton->setObjectName(QString::fromUtf8("clearPushButton"));
        clearPushButton->setMinimumSize(QSize(40, 40));

        horizontalLayout_4->addWidget(clearPushButton);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_12);


        layouEdit_4->addLayout(horizontalLayout_4);


        verticalLayout_2->addLayout(layouEdit_4);


        gridLayout_2->addWidget(groupBox, 0, 0, 1, 1);


        gridLayout->addLayout(gridLayout_2, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 600, 24));
        MainWindow->setMenuBar(menubar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox->setTitle(QString());
        QTableWidgetItem *___qtablewidgetitem = dataTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MainWindow", "number", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = dataTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MainWindow", "qqid", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = dataTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MainWindow", "phone", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = dataTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("MainWindow", "email", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = dataTableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("MainWindow", "name", nullptr));
        qqIdEdit->setText(QString());
        qqIdEdit->setPlaceholderText(QApplication::translate("MainWindow", "QQ id", nullptr));
        phoneIdEdit->setText(QString());
        phoneIdEdit->setPlaceholderText(QApplication::translate("MainWindow", "Phone id", nullptr));
        selectPushButton->setText(QApplication::translate("MainWindow", "\346\237\245\350\257\242", nullptr));
        clearPushButton->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
